# -*- coding: utf-8 -*-
"""
Created on Wed Mar  2 11:59:18 2022

@author: bhook
"""

from setuptools import setup

setup()
